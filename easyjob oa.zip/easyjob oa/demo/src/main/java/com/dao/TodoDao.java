package com.dao;

import com.entity.Todo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface TodoDao {

    List<Todo> findAll();

    void insert(Todo todo);

    Todo update(Todo todo);

    void delete(Todo todo);

    void update1(Todo todo);

}
