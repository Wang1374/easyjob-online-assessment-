package com.controller;

import com.entity.Todo;
import com.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@Controller
public class TodoController {

    @Autowired
    private TodoService todoService;

    @RequestMapping("/findAll")
    public String findAll(Model model) {
        List<Todo> list = todoService.findAll();
        model.addAttribute("resultList", list);
        return "todo";
    }

    @RequestMapping("/insert")
    public void insert(HttpServletResponse response, Todo todo) throws IOException {
        todo.setCreateTime(new Date());
        todoService.insert(todo);
        response.sendRedirect("/findAll");
    }

    @RequestMapping("/delete")
    public void delete(HttpServletResponse response, Todo todo) throws IOException {
        todoService.delete(todo);
        response.sendRedirect("/findAll");
    }

    @RequestMapping("/update")
    public String update( Todo todo,Model model) throws IOException {
        todo.setCreateTime(new Date());
       Todo todo1= todoService.update(todo);
        System.out.println("todo1 = " + todo1);
        model.addAttribute("message", todo1.getMessage());
        model.addAttribute("id", todo1.getId());
        return "update";
    }


    @RequestMapping("/update1")
    public void update1(HttpServletResponse response, Todo todo,Model model) throws IOException {
        todoService.update1(todo);
        response.sendRedirect("/findAll");

    }
}
