package com.service;

import com.entity.Todo;

import java.util.List;

public interface TodoService {

    List<Todo> findAll();

    void insert(Todo todo);

    void delete(Todo todo);

    Todo update(Todo todo);

    void update1(Todo todo);
}
