package com.service.impl;

import com.dao.TodoDao;
import com.entity.Todo;
import com.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TodoServiceImpl implements TodoService {

    @Autowired
    private TodoDao todoDao;

    @Override
    public List<Todo> findAll() {
        List<Todo> list =todoDao.findAll();
        return list;
    }

    @Override
    public void insert(Todo todo) {
        todoDao.insert(todo);
    }

    @Override
    public void delete(Todo todo) {
        todoDao.delete(todo);

    }

    @Override
    public Todo update(Todo todo) {
        Todo update = todoDao.update(todo);
        return  update;
    }

    @Override
    public void update1(Todo todo) {
        todoDao.update1(todo);

    }
}
