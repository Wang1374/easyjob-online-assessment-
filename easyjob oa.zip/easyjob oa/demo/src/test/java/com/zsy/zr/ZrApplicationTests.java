package com.zsy.zr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZrApplicationTests {

    @Test
    void contextLoads() {
    }

}
